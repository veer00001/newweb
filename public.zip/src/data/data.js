export const clutch = [
  { img: "https://www.webbraininfotech.com/img/Clutch.webp" },
  { img: "https://www.webbraininfotech.com/img/goo-re.png" },
  { img: "https://www.webbraininfotech.com/img/glassdoor-logo.png" },
  { img: "https://www.webbraininfotech.com/img/Clutch.webp" },
  { img: "https://www.webbraininfotech.com/img/justdial_logo.png" },
  { img: "https://www.webbraininfotech.com/img/trustpilot.png" },
];

export const vaccancy = [
  {
    name: "React Developer",
    Qualification: "Graduate",
    Description:
      "Anthonie de Lorme (Tournai 1610 or between 1600 and 1605 – Rotterdam, 1673) was a painter known for his depictions of interiors of existing or imaginary ..",
    view: "View Details",
  },
  {
    name: "Web Developer",
    Qualification: "Post Graduate",
    Description:
      "Anthonie de Lorme (Tournai 1610 or between 1600 and 1605 – Rotterdam, 1673) was a painter known for his depictions of interiors of existing or imaginary ..",
    view: "View Details",
  },
  {
    name: "Graphic Designer",
    Qualification: "under Graduate",
    Description:
      "Anthonie de Lorme (Tournai 1610 or between 1600 and 1605 – Rotterdam, 1673) was a painter known for his depictions of interiors of existing or imaginary ..",
    view: "View Details",
  },
];

export const ourTestimonial = [
  {
    Description:
      "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visua.",
    img: "https://images.unsplash.com/photo-1664575602554-2087b04935a5?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8d29tYW58ZW58MHx8MHx8fDA%3D",
    name: "Nat Reynolds",
    profession: "Accoutns",
  },
  {
    Description:
      "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visua.",
    img: "https://plus.unsplash.com/premium_photo-1686244745070-44e350da9d37?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTN8fHdvbWFufGVufDB8fDB8fHww",
    name: "Nat Reynolds",
    profession: "Accoutns",
  },
  {
    Description:
      "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visua.",
    img: "https://images.unsplash.com/photo-1581803118522-7b72a50f7e9f?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTJ8fG1hbnxlbnwwfHwwfHx8MA%3D%3D",
    name: "Nat Reynolds",
    profession: "Accoutns",
  },
  {
    Description:
      "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visua.",
    img: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTh8fG1hbnxlbnwwfHwwfHx8MA%3D%3D",
    name: "Nat Reynolds",
    profession: "Accoutns",
  },
  {
    Description:
      "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visua.",
    img: "https://images.unsplash.com/photo-1615109398623-88346a601842?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTZ8fG1hbnxlbnwwfHwwfHx8MA%3D%3D",
    name: "Nat Reynolds",
    profession: "Accoutns",
  },
  {
    Description:
      "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visua.",
    img: "https://images.unsplash.com/photo-1615109398623-88346a601842?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTZ8fG1hbnxlbnwwfHwwfHx8MA%3D%3D",
    name: "Nat Reynolds",
    profession: "Accoutns",
  },
  {
    Description:
      "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visua.",
    img: "https://images.unsplash.com/photo-1615109398623-88346a601842?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTZ8fG1hbnxlbnwwfHwwfHx8MA%3D%3D",
    name: "Nat Reynolds",
    profession: "Accoutns",
  },
  {
    Description:
      "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visua.",
    img: "https://images.unsplash.com/photo-1615109398623-88346a601842?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTZ8fG1hbnxlbnwwfHwwfHx8MA%3D%3D",
    name: "Nat Reynolds",
    profession: "Accoutns",
  },
];
export const Portfolioimg = [
  {
    Allimg:
      "https://www.webbraininfotech.com/img/Portfolio/amirycashforcars.jpg",
    webImg: "https://www.webbraininfotech.com/img/Portfolio/angelchecks.jpg",
    appImg: "https://www.webbraininfotech.com/img/Portfolio/bentecc.jpg",
    graphic:
      "https://www.webbraininfotech.com/img/Portfolio/cheatingspouse01.jpg",
  },
];

// services

export const webDesign = [
  {
    technology: "Static Website",
    Description: "Static website and somethings with informataion",
    bgimg: "",
  },
  {
    technology: "Static Website",
    Description: "Static website and somethings with informataion",
    bgimg: "",
  },
  {
    technology: "Static Website",
    Description: "Static website and somethings with informataion",
    bgimg: "",
  },
  {
    technology: "Static Website",
    Description: "Static website and somethings with informataion",
    bgimg: "",
  },
  {
    technology: "Static Website",
    Description: "Static website and somethings with informataion",
    bgimg: "",
  },
  {
    technology: "Static Website",
    Description: "Static website and somethings with informataion",
    bgimg: "",
  },
  {
    technology: "Static Website",
    Description: "Static website and somethings with informataion",
    bgimg: "",
  },
  {
    technology: "Static Website",
    Description: "Static website and somethings with informataion",
    bgimg: "",
  },
  {
    technology: "Static Website",
    Description: "Static website and somethings with informataion",
    bgimg: "",
  },
];

export const SEOservices = [
  { name: "Online Presence Analysis", Description: "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.", img: "" },
  { name: "eCommerce SEO", Description: "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.", img: "" },
  { name: "Content Writing", Description: "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.", img: "" },
  { name: "Amazon SEO", Description: "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.", img: "" },
  { name: "Mobile SEO", Description: "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.", img: "" },
  { name: "Local SEO", Description: "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.", img: "" },


];
