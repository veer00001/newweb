import React from "react";
import "./Header.css";

import { Link } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faStar } from "@fortawesome/free-solid-svg-icons";
import {
  faFacebook,
  faLinkedin,
  faSkype,
  faInstagram,
  faTwitter,
} from "@fortawesome/free-brands-svg-icons";

const Header = () => {
  return (
    <header>
      <ul className="header-phone-email">
        <li>
          {" "}
          <Link to="/"> webeach.com</Link>{" "}
          <Link to="/"> +91-11-470-51-378</Link>
        </li>
      </ul>
      <li className="social-icons">
        <Link to="">
          {" "}
          <FontAwesomeIcon icon={faFacebook} />
        </Link>
        <Link to="">
          {" "}
          <FontAwesomeIcon icon={faLinkedin} />
        </Link>
        <Link to="">
          {" "}
          <FontAwesomeIcon icon={faSkype} />
        </Link>
        <Link to="">
          {" "}
          <FontAwesomeIcon icon={faInstagram} />
        </Link>
        <Link to="">
          {" "}
          <FontAwesomeIcon icon={faTwitter} />
        </Link>
      </li>
    </header>
  );
};
export default Header;
