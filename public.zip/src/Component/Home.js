import React from "react";

import MainBanner from "./Carousel/Carousel";
import About from "./About/About";
import HomeTab from "./HomeTab/HomeTab";

import ClientsPartnership from "./ClientsPartnership/ClientsPartnership";
import Testimonial from "./Testimonial/Testimonial";
import ServicesPlan from "./ServicesPlan/ServicesPlan";

const Home = () => {
  return (
    <div>
      <MainBanner />
      <HomeTab />
      <About />

      {/* <Rating/> */}

      <Testimonial />
      <ServicesPlan />
      <ClientsPartnership />
    </div>
  );
};
export default Home;
