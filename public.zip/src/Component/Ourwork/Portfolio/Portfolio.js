import React from "react";
import "./Portfolio.css";
import Tab from "react-bootstrap/Tab";
import Tabs from "react-bootstrap/Tabs";
import { Portfolioimg } from "../../../data/data";

const Portfolio = () => {
  console.log(Portfolioimg);

  return (
    <div className="portFolioParant">
      <Tabs
        defaultActiveKey="profile"
        id="fill-tab-example"
        className="mb-3"
        fill
      >
        <Tab eventKey="Home" title="All Categories">
          <div>
            {Portfolioimg.map((data) => (
              <span>
                <img src={data.webImg} alt="photo" />{" "}
              </span>
            ))}
          </div>
        </Tab>
        <Tab eventKey="Profile" title="Web Development">
          <div>
            {Portfolioimg.map((data) => (
              <span>
                <img src={data.webImg} alt="photo" />{" "}
              </span>
            ))}
          </div>
        </Tab>
        <Tab eventKey="longer-tab" title="App Development">
        <div>
        
        {Portfolioimg.map((data) => (
              <span><img src={data.webImg} alt="photo" /> </span>
        ))}
 
    </div>
        </Tab>
        <Tab eventKey="contact" title="Graphic">
        <div>
        
        {Portfolioimg.map((data) => (
              <span><img src={data.webImg} alt="photo" /> </span>
        ))}
 
    </div>
        </Tab>
      </Tabs>
    </div>
  );
};

export default Portfolio;
