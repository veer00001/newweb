import React, { useState } from "react";
import "./Navbar.css";
import { clutch } from "../../data/data";

import { Link } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faStar, faBars } from "@fortawesome/free-solid-svg-icons";
import AwesomeSlider from "react-awesome-slider";
import "react-awesome-slider/dist/styles.css";
import withAutoplay from "react-awesome-slider/dist/autoplay";
import "react-awesome-slider/dist/styles.css";

const Navabar = () => {
  const [isMobileResponsive, setMobileResponsive] = useState(true);
  const AutoplaySlider = withAutoplay(AwesomeSlider);

  const showMenu = () => {
    setMobileResponsive(!isMobileResponsive);
  };
  return (
    <nav>
      <div>
        <p className="logo">
          <img src="" alt="" />
        </p>
 
      </div>

      {isMobileResponsive ? (
        <ul className="nav-list">
          <li>
            {" "}
            <Link to="/"> Home </Link>{" "}
          </li>

          <li className="servics-drop-down-parant">
            {" "}
            <Link to="/"> Service </Link>
            <ul className="servics-drop-down">
              <li className="social-media-optimi-drop-down">
                {" "}
                <Link to="/SEO"> Search Engine Optimization</Link>
                <ul className="social-media-optimi-drop-down-child">
                  <li>
                    {" "}
                    <Link to="/"> Online Presence Analysis </Link>{" "}
                  </li>

                  <li>
                    {" "}
                    <Link to="/"> eCommerce SEO </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Content Writing</Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Amazon SEO </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Mobile SEO </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Local SEO </Link>{" "}
                  </li>
                </ul>
              </li>

              <li className="social-media-optimi-drop-down">
                {" "}
                <Link to="/AppDevelopment"> Mobile App Development </Link>
                <ul className="social-media-optimi-drop-down-child">
                  <li>
                    {" "}
                    <Link to="/"> Mobile Application Development </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> iPhone iOS App Development </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Blackberry App Development </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Android Game Development</Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Windows App Development </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> iPhone Game Development</Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Android App Development </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Mobile Game Development</Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Hybrid App Development</Link>{" "}
                  </li>
                </ul>
              </li>

              <li className="social-media-optimi-drop-down">
                {" "}
                <Link to="/"> Wordpress Development </Link>
                <ul className="social-media-optimi-drop-down-child">
                  <li>
                    {" "}
                    <Link to="/"> Suggest </Link>{" "}
                  </li>
                </ul>
              </li>

              <li className="social-media-optimi-drop-down">
                {" "}
                <Link to="/"> Website Development </Link>
                <ul className="social-media-optimi-drop-down-child">
                  <li>
                    {" "}
                    <Link to="/"> Web Portal Development</Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Software Development</Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> asp Net Development</Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> AJAX Development</Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Game Development</Link>{" "}
                  </li>
                </ul>
                <ul className="social-media-optimi-drop-down-child leftDrop">
                  <li>
                    {" "}
                    <Link to="/"> eCommerce Web Development </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> CMS Website Development </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Magento Web Development </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Drupal Web Development </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Open Source Solutions </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Website Development </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> PHP Web Development </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Joomla Development </Link>{" "}
                  </li>
                </ul>
              </li>

              <li className="social-media-optimi-drop-down">
                {" "}
                <Link to="/WebsiteDesign"> Website Design </Link>
                <ul className="social-media-optimi-drop-down-child">
                  <li>
                    {" "}
                    <Link to="/"> PSD TO Preshtashop </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> PSD to Bootstrap </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> PSD to Shopify </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> PSD to Joomula </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> PSD to Magento </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Flash Design </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> PSD to HTML </Link>{" "}
                  </li>
                </ul>
                <ul className="social-media-optimi-drop-down-child leftDrop2">
                  <li>
                    {" "}
                    <Link to="/"> Website Maintenance Services</Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> eCommerce Website Design </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Dynamic Website Design </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Static Website Design </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Mobile Website Design</Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Mobile Website Design</Link>{" "}
                  </li>
                </ul>
              </li>

              <li className="social-media-optimi-drop-down">
                {" "}
                <Link to="/"> Pay Per Click (PPC) </Link>
                <ul className="social-media-optimi-drop-down-child">
                  <li>
                    {" "}
                    <Link to="/"> Conversion Rate Optimization </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> PPC Reseller Services </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Display Advertising </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Affiliate Marketing </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Product Listing Ads </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Search Advertising </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Email Marketing </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Amazon Ads</Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> PPC</Link>{" "}
                  </li>
                </ul>
              </li>

              <li className="social-media-optimi-drop-down">
                {" "}
                <Link to="/"> Digital Marketing </Link>
                <ul className="social-media-optimi-drop-down-child">
                  <li>
                    {" "}
                    <Link to="/"> Google Penalty Recovery Services </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Online Reputation Management </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Digital Marketing Services </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> LinkedIn Advertising </Link>{" "}
                  </li>

                  <li>
                    {" "}
                    <Link to="/"> Facebook Advertising </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Twitter Advertising </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Affiliate Marketing</Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Search Advertising </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> YouTube Marketing </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Email Marketing</Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> SMO </Link>{" "}
                  </li>
                </ul>
              </li>

              <li className="social-media-optimi-drop-down">
                {" "}
                <Link to="/">Web Hosting</Link>
                <ul className="social-media-optimi-drop-down-child">
                  <li>
                    {" "}
                    <Link to="/"> Dedicated Server Hosting </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Domain Name Registration </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Reseller Hosting </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Windows Hosting </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Shared Hosting </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Cloud Hosting </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Linux Hosting </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> VPS Hosting </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Web Hosting </Link>{" "}
                  </li>
                </ul>
              </li>

              <li className="social-media-optimi-drop-down">
                {" "}
                <Link to="/"> Graphic</Link>
                <ul className="social-media-optimi-drop-down-child">
                  <li>
                    {" "}
                    <Link to="/"> Banner Design </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Banner Design </Link>{" "}
                  </li>
                  <li>
                    {" "}
                    <Link to="/"> Logo Design </Link>{" "}
                  </li>
                </ul>
              </li>
            </ul>
          </li>

          <li className="servics-drop-down-parant">
            {" "}
            <Link to="/"> About </Link>
            <ul className="servics-drop-down">
              <li className="social-media-optimi-drop-down">
                {" "}
                <Link to="/Abousus"> About Us</Link>
              </li>

              <li className="social-media-optimi-drop-down">
                {" "}
                <Link to="/ourteam"> Our Team </Link>{" "}
              </li>
              <li className="social-media-optimi-drop-down">
                {" "}
                <Link to="/Awards"> Awards </Link>
              </li>
            </ul>
          </li>

          <li className="servics-drop-down-parant">
            {" "}
            <Link to="/"> Our Work</Link>
            <ul className="servics-drop-down">
              <li className="social-media-optimi-drop-down">
                {" "}
                <Link to="/OurTestimonail"> Testimonial</Link>{" "}
              </li>
          
              <li className="social-media-optimi-drop-down">
                {" "}
                <Link to="/Portfolio"> Portfolio </Link>{" "}
              </li>
            </ul>
          </li>

          <li>
            {" "}
            <Link to="/carrer"> Career </Link>{" "}
          </li>
          <li>
            {" "}
            <Link to="/contactus"> Contact </Link>{" "}
          </li>
       
        </ul>
      ) : (
        console.log("flase")
      )}

      <ul className="menubarIconParant" onClick={() => showMenu()}>
        <FontAwesomeIcon icon={faBars} />
      </ul>
    </nav>
  );
};

export default Navabar;
