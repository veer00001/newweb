import React from "react";

const Contact = () => {
  return;
  <div></div>;
};
export default Contact;
