import React from "react";
import "./Webdesigningproject.css";
import Button from "react-bootstrap/Button";
const Webdesigningproject = () => {
  return (
    <div className="webdesingProjectParant">
      <div className="container  webdesingProject">
        <div>
          <h1>See Our Web Demos For Exploring Mre</h1>
          <p>
            LIn publishing and graphic design, Lorem ipsum is a placeholder text
            commonly used to demonstrate the visual form of a document or a
            typeface without relying on meaningful
          </p>
          <Button variant="primary">Web Demo</Button>{" "}
        </div>
        <div className="circlebox">
          <p className="line">
            <span>
              {" "}
              <img src="" alt="img" />{" "}
            </span>
            {""}
          </p>
          <p className="line">
            <span>
              {" "}
              <img src="" alt="img" />{" "}
            </span>
            {""}
          </p>
          <p className="line">
            <span>
              {" "}
              <img src="" alt="img" />{" "}
            </span>
            {""}
          </p>
          <p className="line">
            <span>
              {" "}
              <img src="" alt="img" />{" "}
            </span>
            {""}
          </p>
          <p className="line">
            <span>
              {" "}
              <img src="" alt="img" />{" "}
            </span>
            {""}
          </p>
        </div>
      </div>
    </div>
  );
};

export default Webdesigningproject;
