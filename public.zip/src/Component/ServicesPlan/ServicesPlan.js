import React from "react";
import { Button } from "react-bootstrap";
import "./ServicesPlan.css";

const ServicesPlan = () => {
  return (
    <div className="contaer servicesPlane-parant">
      <div className="servicesplane">
        <div>
          <h2>Need help Choosing a plan?</h2>
          <p>Discover what Microsoft 365 plan is best for your needs.</p>
        </div>

        <div className="servicesButtonParant">
          <Button variant="primary">See</Button>{" "}
          <Button variant="primary">Call Us</Button>{" "}
        </div>
      </div>
      <span>
        <img className="servicesPlaneImg"
          src="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/CTAStacked-ChoosePlan-664x498?resMode=sharp2&op_usm=1.5,0.65,15,0&wid=664&qlt=100&fit=stretch"
        //   src="https://media.licdn.com/dms/image/D5603AQExE472-OY1jQ/profile-displayphoto-shrk_100_100/0/1683553804137?e=1707955200&v=beta&t=v7A44L3DyoZh2jpvFS2DPmHit-XojhAhggnrjeBTPcc"
          alt=""
        />
      </span>
    </div>
  );
};

export default ServicesPlan;
