import React from "react";
import "./Aboutus.css";
import AboutusTimline from "./AboutusTimline/AboutusTimline";

const Aboutus = () => {
  return (
    <div>
      <div className="abutusbanner">
        <h2>WELCOME TO FREE SKETCH TEMPLATE</h2>
        <p>Habitassive serstivulum a min adlo ut retum mauris leo lorem</p>
      </div>
      <div className="aboutussection">
        <div>
          <h1>About us</h1>
          <p>
            Web Brain InfoTech is a privately owned venture founded by two
            entrepreneurs. It’s headquarter is located in New Delhi (NCR),
            India. The company offers complete web solutions to its clients,
          </p>
          <p>
            Web Brain InfoTech has always been renowned for its excellent and
            state of the art digital marketing solutions. We pride ourselves as
            the leading digital marketing company available in the industry
            today. There are numerous digital marketing services that we provide
            to clients from all corners of the business fraternity. We believe
          </p>
        </div>
        <span className="aboutussideimg">
          <img src="https://images.unsplash.com/photo-1551135049-8a33b5883817?q=80&w=1740&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" />{" "}
        </span>
      </div>
      <div>
        <AboutusTimline />
      </div>
    </div>
  );
};

export default Aboutus;
