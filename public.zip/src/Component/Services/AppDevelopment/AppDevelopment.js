import React from "react";
import "./AppDevelopment.css";
import { SEOservices } from "../../../data/data";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faHouse } from "@fortawesome/free-solid-svg-icons";
import { Link } from "react-router-dom";

const AppDevelopment = () => {
  return (
    <div>
      <div className="container  seoTopSection">
        <div>
          <h2>The Best SEO solution with 10+ Years of experience</h2>
          <p>
            In publishing and graphic design, Lorem ipsum is a placeholder text
            commonly used to demonstrate the visual form of a document or a
            typeface without relying on meaningful content. Lorem ipsum may be
            used as a placeholder before final copy is available.
          </p>
          <ul>
            <li>Award Winning</li>
            <li>24/7 Support</li>
            <li>Professional Staff</li>
            <li>Fair Prices</li>
          </ul>
        </div>
        <span>
          <img
            src="https://images.unsplash.com/photo-1562577309-2592ab84b1bc?q=80&w=1674&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
            alt="image missing"
          />
        </span>
      </div>

      <div className="seoServices  container">
        <h2>SEO SERVICES WE PROVIED</h2>
        <div className="seoServicesBoxParant">
          {SEOservices.map((data) => (
            <div>
              <span>
                {" "}
                <FontAwesomeIcon icon={faHouse} />
                {/* <img src="" alt="image missing" />{" "} */}
              </span>
              <h4> {data.name}</h4>
              <p>{data.Description}</p>
              <p>
                {" "}
                <Link to=""> Read More </Link>
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* pricing Table */}

      <div className="SEOpricingTable">
        <div class="container">
          <div class="row">
            <div class="col-md-12 mb-5">
              <h2 class="main-head">PRICING</h2>
            </div>

            <div class="col-md-4">
              <div class="pricing-table purple">
                <div class="pricing-label">Fixed Price</div>
                <h2>BasicPack 2020</h2>
                <h5>Made for starters</h5>

                <div class="pricing-features">
                  <div class="feature">
                    Bandwith<span>50 GB</span>
                  </div>
                  <div class="feature">
                    Add-On Domains<span>10</span>
                  </div>
                  <div class="feature">
                    SSD Storage<span>250 GB</span>
                  </div>
                  <div class="feature">
                    Mail Adresses<span>25</span>
                  </div>
                  <div class="feature">
                    Support<span>Only Mail</span>
                  </div>
                </div>

                <div class="price-tag">
                  <span class="symbol">$</span>
                  <span class="amount">7.99</span>
                  <span class="after">/month</span>
                </div>

                <a class="price-button" href="#">
                  Get Started
                </a>
              </div>
            </div>

            <div class="col-md-4">
              <div class="pricing-table turquoise">
                <div class="pricing-label">Fixed Price</div>
                <h2>ExtendedPack 2020</h2>
                <h5>Made for experienced users</h5>

                <div class="pricing-features">
                  <div class="feature">
                    Bandwith<span>150 GB</span>
                  </div>
                  <div class="feature">
                    Add-On Domains<span>25</span>
                  </div>
                  <div class="feature">
                    SSD Storage<span>500 GB</span>
                  </div>
                  <div class="feature">
                    Mail Adresses<span>50</span>
                  </div>
                  <div class="feature">
                    Support<span>Mail/Phone</span>
                  </div>
                </div>

                <div class="price-tag">
                  <span class="symbol">$</span>
                  <span class="amount">9.99</span>
                  <span class="after">/month</span>
                </div>

                <a class="price-button" href="#">
                  Get Started
                </a>
              </div>
            </div>

            <div class="col-md-4">
              <div class="pricing-table red">
                <div class="pricing-label">Fixed Price</div>
                <h2>ProsPack 2020</h2>
                <h5>Made for professionals/agencies</h5>

                <div class="pricing-features">
                  <div class="feature">
                    Bandwith<span>250 GB</span>
                  </div>
                  <div class="feature">
                    Add-On Domains<span>50</span>
                  </div>
                  <div class="feature">
                    SSD Storage<span>1 TB</span>
                  </div>
                  <div class="feature">
                    Mail Adresses<span>75</span>
                  </div>
                  <div class="feature">
                    Support<span>7/24</span>
                  </div>
                </div>

                <div class="price-tag">
                  <span class="symbol">$</span>
                  <span class="amount">12.99</span>
                  <span class="after">/month</span>
                </div>

                <a class="price-button" href="#">
                  Get Started
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AppDevelopment;
